//
//  Photo+CoreDataClass.swift
//  Photorama
//
//  Created by Peloso, Christopher St on 2/27/19.
//  Copyright © 2019 Peloso, Christopher St. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Photo)
public class Photo: NSManagedObject {

}
