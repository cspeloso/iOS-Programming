//
//  ItemsViewController.swift
//  Homepwner
//
//  Created by Peloso, Christopher St on 2/6/19.
//  Copyright © 2019 Peloso, Christopher St. All rights reserved.
//
//Dercio Da Silva Torres

import UIKit

class ItemsViewController: UITableViewController {
    
    var itemStore: ItemStore!
    
    @IBAction func addNewItem(_ sender: UIButton){
        /*
        //Makes a new index path for the 0th section, last row
        let lastRow = tableView.numberOfRows(inSection: 0)
        let indexpath = IndexPath(row: lastRow, section: 0)
        
        //inserts new row into table
        tableView.insertRows(at: [indexPath], with: .automatic)
         ABOVE CRASHES BC ITEMSTORE AND THE CONTROLLER DONT AGREE ON THE STORES SIZE
         */
        
        //create a  new item and add it to the store
        let newItem = itemStore.createItem()
        
        //let finalItem = itemStore.createItem2()
        //let finalItem = itemStore.createItem2()
        
        //Figure out where that item is in the array
        if let index = itemStore.allItems.index(of: newItem) {
            let indexPath = IndexPath(row: index, section: 0)
            
            //insert new row into table
            tableView.insertRows(at: [indexPath], with: .automatic)
        }
        
        /*if let index = itemStore.allItems.index(of: finalItem) {
            let indexPath = IndexPath(row: index, section: 0)
            
            tableView.insertRows(at: [indexPath], with: .automatic)
        }*/
        /*
         
        let itemThing = Item(name: "NO LAST ITEM", serialNumber: "2j", valueInDollars: 0)
        
        let lastItemThing = itemStore.createItem(itemThing)

        
        if let index2 = itemStore.allItems.index(of: lastItemThing) {
            let indexPath = IndexPath(row: index2, section: 0)
            
            tableView.insertRows(at: [indexPath], with: .automatic)
        }*/
    }
    
    @IBAction func toggleEditingMode(_ sender: UIButton){
        if isEditing{
            //cahnges text of the button to let user know the state changed
            sender.setTitle("Edit", for: .normal)
            
            //turns off editing mode
            setEditing(false, animated: true)
        }
        else{
            //change text of the button to let user know the state changed
            sender.setTitle("Done", for: .normal)
            
            //enters editing mode
            setEditing(true, animated: true)
        }
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return itemStore.allItems.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //let cell = UITableViewCell(style: .value1, reuseIdentifier: "UITableViewCell")
        //let cell = tableView.dequeueReusableCell(withIdentifier: "UITableViewCell", for: indexPath)
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: indexPath) as! ItemCell
        let item = itemStore.allItems[indexPath.row]
        
        //cell.textLabel?.text = item.name
        //cell.detailTextLabel?.text = "$\(item.valueInDollars)"
        
        
        //Configure the cell within the Item
        cell.nameLabel.text = item.name
        cell.serialNumberLabel.text = item.serialNumber
        cell.valueLabel.text = "$\(item.valueInDollars)"
        
        if(item.valueInDollars >= 50){
            cell.valueLabel.textColor = UIColor.green
        }
        else{
            cell.valueLabel.textColor = UIColor.red
        }
        
        
        return cell
    }
    
    /*override func tableView(_ tableView: UITableView, cellForRowAt lastIndexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ItemCell", for: lastIndexPath) as! ItemCell
        let item = itemStore.allItems[lastIndexPath.row]
        
        cell.nameLabel.text = "NO LAST NAME"
        cell.serialNumberLabel.text = ""
        cell.valueLabel.text = "$\(0)"
        
        return cell
    }*/
    
    override func viewDidLoad(){
        super.viewDidLoad()
        
        let statusBarHeight = UIApplication.shared.statusBarFrame.height
        
        let insets = UIEdgeInsets(top: statusBarHeight, left: 0, bottom: 0, right: 0)
        
        tableView.contentInset = insets
        tableView.scrollIndicatorInsets = insets
        
        //tableView.rowHeight = 65
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 65
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            let item = itemStore.allItems[indexPath.row]
            
            let title = "Delete \(item.name)?"
            let message = "Are you sure you want to delete this item?"
            
            let ac = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
            
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
            ac.addAction(cancelAction)
            
            let deleteAction = UIAlertAction(title: "Remove", style: .destructive, handler: { (action) -> Void in
                
                self.itemStore.removeItem(item)
                
                self.tableView.deleteRows(at: [indexPath], with: .automatic)
                
            })
            
            ac.addAction(deleteAction)
            
            present(ac,animated: true, completion: nil)
        }
    }
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath){
        //update the model
        itemStore.moveItem(from: sourceIndexPath.row, to: destinationIndexPath.row)
    }
    
    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        //let newItemThing = Item(name: "NO MORE ITEMS", serialNumber: "", valueInDollars: 0)
        
        
        return "No more items."
    }
    
    override func tableView(_ tableView: UITableView, titleForDeleteConfirmationButtonForRowAt indexPath: IndexPath) -> String? {
        return "Remove"
    }
    
}
