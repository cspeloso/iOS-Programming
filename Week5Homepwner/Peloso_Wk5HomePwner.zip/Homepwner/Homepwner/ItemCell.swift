//
//  ItemCell.swift
//  Homepwner
//
//  Created by Peloso, Christopher St on 2/6/19.
//  Copyright © 2019 Peloso, Christopher St. All rights reserved.
//

import UIKit

class ItemCell: UITableViewCell {
    
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var serialNumberLabel: UILabel!
    @IBOutlet var valueLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        nameLabel.adjustsFontForContentSizeCategory = true
        serialNumberLabel.adjustsFontForContentSizeCategory = true
        valueLabel.adjustsFontForContentSizeCategory = true
        
        /*
        if(Int(valueLabel.text!)! >= 50){
            valueLabel.textColor = UIColor.green
        }
        else{
            valueLabel.textColor = UIColor.red
        }
        */
        
        //valueLabel.textColor = UIColor.green
        /*
        if(Int(self.valueLabel.text) < 50){
            valueLabel.textColor = UIColor.red
        }
        else{
            valueLabel.textColor = UIColor.green
        }*/
        
        
        
    }
    
}
