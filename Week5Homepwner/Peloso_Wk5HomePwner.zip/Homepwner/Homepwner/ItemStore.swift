//
//  ItemStore.swift
//  Homepwner
//
//  Created by Peloso, Christopher St on 2/6/19.
//  Copyright © 2019 Peloso, Christopher St. All rights reserved.
//

import UIKit

class ItemStore{
    
    let finalItem = Item(name: "NO MORE ITEMS", serialNumber: "", valueInDollars: 0)
    
    var allItems = [Item]()
    
    @discardableResult func createItem() -> Item {
        let newItem = Item(random:true)
        //let finalItem = Item(name: "NO MORE ITEMS", serialNumber: "", valueInDollars: 0)

        //allItems.remove(at: allItems.count)
        allItems.append(newItem)
        //allItems.append(finalItem)
        
        
        
        return newItem
    }
    
    /*@discardableResult func createItem2() -> Item{
        let finalItem = Item(name: "NO MORE ITEMS", serialNumber: "", valueInDollars: 0)

        /*if(allItems.count > 0){
            allItems.remove(at: allItems.count)
        }*/
        
        allItems.append(finalItem)
        
        return finalItem
    }*/
    
    //initializes the store with 5 items.
    //removed after adding ability to add items in the app
    /*init() {
        for _ in 0..<5 {
            createItem()
        }
    }*/
    
    func removeItem(_ item: Item){
        if let index = allItems.index(of: item){
            allItems.remove(at: index)
        }
    }
    
    func moveItem(from fromIndex: Int, to toIndex: Int){
        if fromIndex == toIndex{
            return
        }
        
        
        
        let movedItem = allItems[fromIndex]
        
        allItems.remove(at: fromIndex)
        
        allItems.insert(movedItem, at: toIndex)
        
        
    }
    
    
    
    
    
}
