//
//  ViewController.swift
//  WorldTrotter
//
//  Created by Peloso, Christopher St on 1/23/19.
//  Copyright © 2019 Peloso, Christopher St. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad(){
        //after the view controller's view is loaded into memory, it's viewDidLoad() method is called.
        //super.viewDidLoad()
        
        /*This creates a rectangle "frame." It's X and Y values are it's placement on the screen;
        width and height are it's dimensions. These are in points, not pixels. Pixels would look
        different on different resolution phone screens, while points are calculated automatically
         to adjust resolution on different displays (i.e. retina vs. non-retina screens.) or
         something like that. So the box's top left corner is 160 points from the left side of
         the screen and 240 points down from the top of the screen.*/
        //let firstFrame = CGRect(x: 160, y: 240, width: 100, height: 150)
        //Adds the frame above to the first view.
        //let firstView = UIView(frame: firstFrame)
        //changes the view's color to blue.
        //firstView.backgroundColor = UIColor.blue
        //view.addSubview(firstView)
        
        /* Here, I am creating another subview. This is displayed on the same "level" as the first
         view. They are both subviews of the ViewController View; The ViewController view is a
         superview to both of them.*/
        //let secondFrame = CGRect(x: 20, y: 30, width: 50, height: 50)
        //let secondView = UIView(frame: secondFrame)
        //secondView.backgroundColor = UIColor.green
        /*originally this was on the same level of hierarchy as the first view, both being a subview
         of the viewcontroller view. Instead, it's being changed to a subview of the first view.*/
        //view.addSubview(secondView)
        
        /* After executing the command below, secondview is now a subview of first view.
         This changes the placement of the green square so that it is now inside of the blue rectangle,
         and any changes made to placement are according to the blue square and not the whole phone
         screen. (When moved 30 points down and 20 points to the right, it isn't moved from the top
         and side of the phone screen anymore. It's moved from the top and side of the blue rectangle.)*/
        //firstView.addSubview(secondView)
        
        
    }
    
}

